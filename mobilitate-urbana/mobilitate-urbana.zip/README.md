# OpenFreeMap + @vis.gl/react-maplibre Example

Built with [@vis.gl/react-maplibre](https://visgl.github.io/react-maplibre/)

```sh
pnpm install
pnpm dev
```
